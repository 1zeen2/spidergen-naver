/**
Constructor
*/
class economy extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changeEconomyTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}

	changeEconomyTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changeEconomyTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}

	changeEconomyTabToSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changeEconomyTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changeEconomyTabToShoppingTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝

}

window["economy"] = economy