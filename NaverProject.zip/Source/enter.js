/**
Constructor
*/
class enter extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changeEnterTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}

	changeEnterTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changeEnterTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}

	changeEnterTabToSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changeEnterTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changeEnterTabToShoppingTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝

}

window["enter"] = enter