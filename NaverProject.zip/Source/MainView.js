/**
Constructor
*/
class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()
		this.newsstand.selectTabById('tab1');
		
		this.newsstand.addtab( '뉴스스탠드', 'Source/view/tab1.lay', 'tab1');
		this.newsstand.addtab( '언론사편집', 'Source/view/tab2.lay', 'tab2');
		this.newsstand.addtab( '엔터', 'Source/view/tab2.lay', 'tab3');
		this.newsstand.addtab( '스포츠', 'Source/view/sports.lay', 'sports');
		this.newsstand.addtab( '경제', 'Source/view/economy.lay', 'economy');

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

}

window["MainView"] = MainView