/**
Constructor
*/
class MainView extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()
		this.Mainview.addItem('Source/sideviewtest.lay');
		
	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)


	}

}

window["MainView"] = MainView('Source/MainView.lay');