/**
Constructor
*/
class pressedit2 extends AView
{
	constructor()
	{
		super()

		this.rollingInterval = null;
		this.currentIndex = 0;
		this.rollingItems = [];

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		const item1 = this.getComponenetById('AutoRolling-module1__rolling-y');
		const item2 = this.getComponenetById('AutoRolling-module2__rolling-y');

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		if (isFirst) {
			this.startRolling();
		}

	}
	
	startRolling() {
        if (this.rollingItems && this.rollingItems.length === 2) {
            this.rollingInterval = setInterval(() => {
                this.updateRolling();
            }, 500); 
        }
    }
	
	updateRolling() {
        this.rollingItems[this.currentIndex].setVisible(false);

        this.currentIndex = 1 - this.currentIndex;

        this.rollingItems[this.currentIndex].setVisible(true);
		
    }
	
	onDestroy() {
        super.onDestroy();
        if (this.rollingInterval) {
            clearInterval(this.rollingInterval);
        }
    }

	onNextButtonClick(comp, info, e)
	{

		//TODO:edit here

	}

}

window["pressedit2"] = pressedit2