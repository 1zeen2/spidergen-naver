/**
Constructor
*/
class shoppingtoday extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changeShoppingTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}

	changeShoppingTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changeShoppingTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}

	changeShoppingTabSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changeShoppingTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changeShoppingTabToShoppingtodayTab(comp, info, e)
	{

		this.owner.selectTabById('shoppingtoday');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝

}

window["shoppingtoday"] = shoppingtoday