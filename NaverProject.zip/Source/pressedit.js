/**
Constructor
*/
class pressedit extends AView
{
	constructor()
	{
		super()

		this.rollingInterval = null;
		this.currentIndex = 0;
		this.rollingItems = [];

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		const item1 = this.getComponentById('AutoRolling-module1__rolling-y');
		const item2 = this.getComponentById('AutoRolling-module2__rolling-y');
		
		if (item1 && item2) {
             this.rollingItems = [item1, item2];
             
             item1.setVisible(true);
             item2.setVisible(false);
             
             this.currentIndex = 0;
             
        } else {
             console.error("롤링 대상 컴포넌트를 찾을 수 없습니다. ID 확인 필요.");
        }

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)
		
		if (isFirst && this.rollingItems.length === 2) {
			this.startRolling();
		}

	}
	
	startRolling() {
        if (this.rollingItems && this.rollingItems.length === 2) {
            this.rollingInterval = setInterval(() => {
                this.updateRolling();
            }, 500); 
        }
    }
	
	updateRolling() {
        this.rollingItems[this.currentIndex].setVisible(false);

        this.currentIndex = 1 - this.currentIndex;

        this.rollingItems[this.currentIndex].setVisible(true);
		
    }
	
	onDestroy() {
        super.onDestroy();
        if (this.rollingInterval) {
            clearInterval(this.rollingInterval);
        }
    }
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changePresseditTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}

	changePresseditTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changePresseditTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}

	changePresseditTabToSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changePresseditTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changePresseditTabToShoppingTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝


	pressEditNextButtonClick(comp, info, e)
	{

		this.owner.selectTabById('pressedit2');

	}


}

window["pressedit"] = pressedit