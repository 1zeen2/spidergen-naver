/**
Constructor
*/
class newsstand extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()


	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changeNewsstandTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}
	
	changeNewsstandTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changeNewsstandTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}

	changeNewsstandTabToSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changeNewsstandTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changeNewsstandTabToShoppingTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝


	onNextButtonClick(comp, info, e)
	{
		this.owner.selectTabById('newsstand2');

	}

}

window["newsstand"] = newsstand