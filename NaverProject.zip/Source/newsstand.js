/**
Constructor
*/
class newsstand extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()


	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

	changeNewsstandTabToEnterTab(comp, info, e)
	{
		this.newsstand.selectTabById('enter');
		

	}

	changeNewsstandTabToEditpressTab(comp, info, e)
	{

		this.changeNewsstandTabToEditpressTab(comp:Menu_tab_item, 'Source/Newsstand/newsstand.lay', 'pressedit');

	}

}

window["newsstand"] = newsstand