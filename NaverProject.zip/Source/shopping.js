/**
Constructor
*/
class shopping extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

	change_shoppingTabToMensTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}

	change_shoppingTabToBrandshopTab(comp, info, e)
	{

		this.owner.selectTabById('shopping_brandshop');

	}

	change_shoppingTabToRecohotdealTab(comp, info, e)
	{

		this.owner.selectTabById('shopping_recohotdeal');

	}

	change_shoppingTabToshoppingliveTab(comp, info, e)
	{

		this.owner.selectTabById('shopping_shoppinglive');

	}

}

window["shopping"] = shopping