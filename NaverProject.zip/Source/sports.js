/**
Constructor
*/
class sports extends AView
{
	constructor()
	{
		super()

		//TODO:edit here

	}

	init(context, evtListener)
	{
		super.init(context, evtListener)

		//TODO:edit here

	}

	onInitDone()
	{
		super.onInitDone()

		//TODO:edit here

	}

	onActiveDone(isFirst)
	{
		super.onActiveDone(isFirst)

		//TODO:edit here

	}

	// MainView의 mainNewsstand TabView를 변경하는 이벤트 시작

	changeSportsTabToNewsstandTab(comp, info, e)
	{

		this.owner.selectTabById('newsstand');

	}

	changeSportsTabToPresseditTab(comp, info, e)
	{

		this.owner.selectTabById('pressedit');

	}

	changeSportsTabToEnterTab(comp, info, e)
	{

		this.owner.selectTabById('enter');

	}
	
	changeSportsTabToSportsTab(comp, info, e)
	{

		this.owner.selectTabById('sports');

	}

	changeSportsTabToEconomyTab(comp, info, e)
	{

		this.owner.selectTabById('economy');

	}

	changeSportsTabToShoppingTab(comp, info, e)
	{

		this.owner.selectTabById('shopping');

	}
	
	// MainView의 mainNewsstand TabView를 변경하는 이벤트 끝
	
}

window["sports"] = sports